I have implemented a server and a client to transfer file data between them. 
The implementation does expect packet loss, handling by Stop-and-Wait mechanism.
For details, please feel free to take a look at step-by-step comments in the source code.

gcc -o sha256 sha256.c -lssl -lcrypto
sudo tc qdisc add dev ens1f0np0 root netem loss 1%
sudo tc qdisc del dev ens1f0np0 root netem
